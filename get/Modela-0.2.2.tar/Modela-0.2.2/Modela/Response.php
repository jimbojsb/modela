<?php
class Modela_Response
{
    
}