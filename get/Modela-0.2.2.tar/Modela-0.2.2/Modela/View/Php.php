<?php
class Modela_View_Php extends Modela_View
{
    
}