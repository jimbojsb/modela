<?php
class Modela_Exception extends Exception
{
	
}