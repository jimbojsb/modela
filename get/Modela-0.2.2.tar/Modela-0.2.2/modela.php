#!/usr/bin/env php
<?php
set_include_path(get_include_path . PATH_SEPARATOR . realpath(dirname(__FILE__) . '/../'));
require_once 'Modela/Loader.php';
$loader = Modela_Loader::getInstance();

$cli = new Modela_Cli($argv);
$cli->run();